package com.habib.studyapp;
import android.app.*; import android.os.*; import android.graphics.Color; import android.view.*; import android.widget.*; import java.util.*;

public class MainActivity extends Activity {
 TextView q,p; RadioGroup opts; Button next; int i=0,score=0;
 String[][] data={{"হিমালয়ের সন্ধিবিচ্ছেদ কোনটি?","হিম + আলয়","হিম + অচল","হিম + আচল","হিম + অলয়","2"},
 {"অ + অ = ?","এ","আ","ও","ঈ","2"},
 {"A little সাধারণত কী বোঝায়?","কিছুই নয়","অল্প পরিমাণ","অনেক","শুধু সংখ্যা","2"},
 {"Deer-এর plural কী?","Deers","Deer","Deeres","Deer’s","2"},
 {"Sun কোন ধরনের noun?","Proper","Common","Abstract","Collective","2"}};
 public void onCreate(Bundle b){super.onCreate(b); setContentView(R.layout.activity_main);
  q=findViewById(R.id.question);p=findViewById(R.id.progress);opts=findViewById(R.id.options);next=findViewById(R.id.next);
  next.setOnClickListener(v->answer()); show();
 }
 void show(){if(i>=data.length){q.setText("পরীক্ষা শেষ!");p.setText("তোমার স্কোর: "+score+"/"+data.length);opts.setVisibility(View.GONE);next.setText("আবার দাও");next.setOnClickListener(v->{i=0;score=0;opts.setVisibility(View.VISIBLE);show();});return;}
  p.setText("প্রশ্ন "+(i+1)+" / "+data.length);q.setText(data[i][0]);int[] ids={R.id.a,R.id.b,R.id.c,R.id.d};
  for(int k=0;k<4;k++){RadioButton r=findViewById(ids[k]);r.setText((char)('ক'+k)+") "+data[i][k+1]);} opts.clearCheck();next.setText(i==data.length-1?"ফলাফল":"পরের প্রশ্ন");
 }
 void answer(){int id=opts.getCheckedRadioButtonId();if(id==-1){Toast.makeText(this,"একটি উত্তর নির্বাচন করো",Toast.LENGTH_SHORT).show();return;}
  int[] ids={R.id.a,R.id.b,R.id.c,R.id.d};int sel=0;for(int k=0;k<4;k++)if(id==ids[k])sel=k+1;
  if(sel==Integer.parseInt(data[i][5]))score++;i++;show();
 }
}